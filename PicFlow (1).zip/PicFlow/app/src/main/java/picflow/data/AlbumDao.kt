package picflow.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow
import picflow.model.Album

/** CRUD sobre la tabla "albumes". */
@Dao
interface AlbumDao {

    // READ: Flow = la lista se vuelve a emitir sola cada vez que la tabla cambia
    @Query("SELECT * FROM albumes ORDER BY id DESC")
    fun observarTodos(): Flow<List<Album>>

    @Query("SELECT * FROM albumes WHERE id = :id")
    suspend fun obtenerPorId(id: Int): Album?

    // CREATE: devuelve el id generado
    @Insert
    suspend fun insertar(album: Album): Long

    // UPDATE: usa el id para saber qué fila reemplazar
    @Update
    suspend fun actualizar(album: Album)

    // DELETE
    @Delete
    suspend fun eliminar(album: Album)
}
