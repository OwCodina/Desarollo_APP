# PicFlow

App Android (Kotlin + Jetpack Compose + MVVM) para capturar, editar y organizar imágenes.
Este avance (Semana 8) implementa el módulo de **álbumes**: listado, formulario con validación y detalle.

**Integrantes:** _(completar)_
**Problemática:** las personas toman muchas fotos, las editan en una app, las guardan en otra y las pierden sin orden.
**Objetivo general:** desarrollar una app móvil que permita capturar, editar y organizar imágenes en un solo flujo.
**Tecnologías:** Kotlin, Jetpack Compose, Material 3, MVVM, Navigation Compose (rutas tipadas), GitHub.

## Trazabilidad del avance

| Requerimiento | Pantalla | Lógica | Prueba |
|---|---|---|---|
| RF08 Crear álbumes | CrearAlbumScreen | AlbumViewModel.registrar() | AlbumViewModelTest |
| RF08 Listar / ver álbum | AlbumesScreen, DetalleAlbumScreen | AlbumViewModel.buscarAlbum() | flujo manual |

Validaciones: nombre obligatorio, 3 a 60 caracteres, **regla propia: no se repiten nombres de álbum**;
descripción máx. 240; tipo obligatorio. Los errores no borran lo escrito. Éxito: mensaje en el detalle.

## Estructura
```
app/src/main/java/picflow/
├── MainActivity.kt
├── model/Album.kt
├── viewmodel/{AlbumUiState,AlbumViewModel}.kt
├── navigation/AppNavigation.kt
└── ui/{album/*, theme/*}
```

## Cómo ejecutarlo
- **Android Studio:** File > Open > carpeta del proyecto > esperar Sync > Run.
- **Sin PC potente:** al hacer push, GitHub Actions compila y publica el APK (pestaña Actions > artefacto `PicFlow-debug-apk`).
